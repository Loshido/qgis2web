# Do not make changes to the following files in this directory

- canvas-size.html
- full-screen.html

To customize templates, take a copy of one of these. These two files get
overwritten when qgis2web is upgraded.